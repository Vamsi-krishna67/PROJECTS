package com.web.model;

import jakarta.persistence.*;
import com.fasterxml.jackson.annotation.JsonIncludeProperties;
import java.time.LocalDateTime;

@Entity
public class Appointment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private LocalDateTime appointmentTime;
    private String status; // PENDING, CONFIRMED, CANCELLED
    
    @ManyToOne
    @JoinColumn(name = "doctor_id")
    @JsonIncludeProperties({"id", "name", "specialization"})
    private Doctor doctor;
    
    @ManyToOne
    @JoinColumn(name = "patient_id")
    @JsonIncludeProperties({"id", "name", "age"})
    private Patient patient;
    
    
    
    public Appointment() {
		
	}
    
    
	public Appointment(Long id, LocalDateTime appointmentTime, String status, Doctor doctor, Patient patient) {
		super();
		this.id = id;
		this.appointmentTime = appointmentTime;
		this.status = status;
		this.doctor = doctor;
		this.patient = patient;
	}

	

	// Getters and setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public LocalDateTime getAppointmentTime() { return appointmentTime; }
    public void setAppointmentTime(LocalDateTime appointmentTime) { this.appointmentTime = appointmentTime; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public Doctor getDoctor() { return doctor; }
    public void setDoctor(Doctor doctor) { this.doctor = doctor; }
    public Patient getPatient() { return patient; }
    public void setPatient(Patient patient) { this.patient = patient; }


	@Override
	public String toString() {
		return "Appointment [id=" + id + ", appointmentTime=" + appointmentTime + ", status=" + status + ", doctor="
				+ doctor + ", patient=" + patient + "]";
	}
    
    
    
    
}