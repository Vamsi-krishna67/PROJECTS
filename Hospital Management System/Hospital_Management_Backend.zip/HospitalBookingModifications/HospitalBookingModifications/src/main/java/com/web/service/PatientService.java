package com.web.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.web.model.Patient;
import com.web.repository.PatientRepository;

@Service
public class PatientService {

    @Autowired
    private PatientRepository patientRepository;

    public Patient addPatient(Patient patient) {
        return patientRepository.save(patient);
    }

    public List<Patient> getAllPatients() {
        return patientRepository.findAll();
    }

    public Optional<Patient> getPatientById(Long id) {
        return patientRepository.findById(id);
    }

    public Patient updatePatient(Long id, Patient updatedPatient) {
        return patientRepository.findById(id).map(patient -> {
            patient.setName(updatedPatient.getName());
            patient.setAge(updatedPatient.getAge());
            patient.setGender(updatedPatient.getGender());
            patient.setBloodGroup(updatedPatient.getBloodGroup());
            patient.setContactNumber(updatedPatient.getContactNumber());
            patient.setEmergencyContact(updatedPatient.getEmergencyContact());
            patient.setAddress(updatedPatient.getAddress());
            patient.setMedicalHistory(updatedPatient.getMedicalHistory());
            patient.setAllergies(updatedPatient.getAllergies());
            patient.setDiagnosis(updatedPatient.getDiagnosis());
            return patientRepository.save(patient);
        }).orElse(null);
    }

    public void deletePatient(Long id) {
        patientRepository.deleteById(id);
    }
}