package com.web.repository;

import java.time.LocalDateTime;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.web.model.Appointment;

@Repository
public interface AppointmentRepository extends JpaRepository<Appointment, Long> {
    List<Appointment> findByDoctorId(Long doctorId);
    List<Appointment> findByPatientId(Long patientId);
    
    @Query("SELECT a FROM Appointment a JOIN FETCH a.patient WHERE a.doctor.id = :doctorId")
    List<Appointment> findAppointmentsWithPatientsByDoctorId(Long doctorId);
    
    // Add this new method to fetch appointments with doctor details
    @Query("SELECT a FROM Appointment a JOIN FETCH a.doctor WHERE a.patient.id = :patientId")
    List<Appointment> findAppointmentsWithDoctorsByPatientId(Long patientId);
	List<Appointment> findByDoctorIdAndAppointmentTimeBetween(Long id, LocalDateTime minusMinutes,
			LocalDateTime plusMinutes);
}