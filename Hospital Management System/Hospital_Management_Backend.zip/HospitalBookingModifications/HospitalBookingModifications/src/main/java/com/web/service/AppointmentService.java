package com.web.service;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.web.model.Appointment;
import com.web.repository.AppointmentRepository;

@Service
@Transactional
public class AppointmentService {    
    @Autowired
    private AppointmentRepository appointmentRepository;
    
    @Autowired
    private DoctorService doctorService;
    
    @Autowired
    private PatientService patientService;

    public Appointment bookAppointment(Appointment appointment) {
        // Validate appointment time is in the future
        if (appointment.getAppointmentTime().isBefore(LocalDateTime.now())) {
            throw new IllegalArgumentException("Appointment time must be in the future");
        }

        // Check if doctor exists
        if (!doctorService.getDoctorById(appointment.getDoctor().getId()).isPresent()) {
            throw new IllegalArgumentException("Doctor not found");
        }

        // Check if patient exists
        if (!patientService.getPatientById(appointment.getPatient().getId()).isPresent()) {
            throw new IllegalArgumentException("Patient not found");
        }

        // Check doctor availability
        List<Appointment> existingAppointments = appointmentRepository
            .findByDoctorIdAndAppointmentTimeBetween(
                appointment.getDoctor().getId(),
                appointment.getAppointmentTime().minusMinutes(30),
                appointment.getAppointmentTime().plusMinutes(30)
            );

        if (!existingAppointments.isEmpty()) {
            throw new IllegalStateException("Doctor is not available at the requested time");
        }

        // Set default status if not provided
        if (appointment.getStatus() == null || appointment.getStatus().isEmpty()) {
            appointment.setStatus("PENDING");
        }

        return appointmentRepository.save(appointment);
    }

    public List<Appointment> getDoctorAppointments(Long doctorId) {
        return appointmentRepository.findByDoctorId(doctorId);
    }

    public List<Appointment> getPatientAppointments(Long patientId) {
        return appointmentRepository.findByPatientId(patientId);
    }
    
    public Appointment updateAppointmentStatus(Long appointmentId, String status) {
        Appointment appointment = appointmentRepository.findById(appointmentId)
            .orElseThrow(() -> new IllegalArgumentException("Appointment not found"));
        
        if (!List.of("CONFIRMED", "CANCELLED", "REJECTED").contains(status)) {
            throw new IllegalArgumentException("Invalid status");
        }
        
        appointment.setStatus(status);
        return appointmentRepository.save(appointment);
    }
}